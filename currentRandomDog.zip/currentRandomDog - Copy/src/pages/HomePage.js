import React from 'react';

function HomePage() {
  return (
    <article>
      <h2>Home</h2>
        <p>
          This program will generate a dog at random. Click above to generate with country of origin and a link to additional information
          <img src="https://www.petmd.com/sites/default/files/2020-11/picture-of-golden-retriever-dog_0.jpg" />
        </p>
    </article>
  );
}

export default HomePage;