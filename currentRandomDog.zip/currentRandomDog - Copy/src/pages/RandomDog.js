import React from 'react';
import '../index.css';

class RandomDog extends React.Component {
  constructor() {
    super();

    this.state = {
      items: []
    }
  }
  componentDidMount() {
    this.getItems();
  }
  getItems() {
    let random = Math.floor(Math.random() * 355);
    fetch(`http://localhost:3000/dogs/${random}`)
      .then(results => results.json())
      .then(results => this.setState({'items': [results]}));
  }
  render() {
    return (
      <ul>
        {this.state.items.map(function(item, index) {          
          return (
            <div>
              <h1>{item.name}</h1>
              <h3>{item.country}</h3>
              <img src={item.image} alt="Image did not render" />
              <h3><a href={item.url}>Click here for more information about the {item.name}</a></h3>
            </div>
            )
          }
        )}
      </ul>
    );
  }
}

export default RandomDog;
