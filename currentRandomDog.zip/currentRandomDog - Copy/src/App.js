import './App.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import React from 'react';
import RandomDog from './pages/RandomDog';
import HomePage from './pages/HomePage';
import Navigation from './components/Navigation';

function App() {  

  return (
    <div className="App">
      <Router>
        <header>
          <h1>
            Random Dog Generator
          </h1>
          <p>
            Returning to the home page will allow you to generate another random dog.
          </p>
        </header>
        <Navigation />
        <main className="App-header">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/RandomDog" element={<RandomDog />} />
        </Routes>
        </main>
        <footer>
          <p>©2022 Adam Ollar</p>
        </footer>
      </Router>
    </div>
  );
}

export default App;