import { Link } from 'react-router-dom';
import React from 'react';

function Navigation () {
    return (
    <nav a>
        <Link className='App-link' to = '/'>Go to the home page</Link>
        <Link className='App-link' to = '/RandomDog'>Click to generate a random dog! </Link>
    </nav>
    );
}

export default Navigation;